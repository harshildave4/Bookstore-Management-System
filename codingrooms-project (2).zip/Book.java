public class Book {
    private String title;
    private String author;
    private String isbn;
    private double price;
    private int inventoryInStock;

    //Constructor
    public Book(String title, String author, String isbn, double price, int inventoryInStock) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.price = price;
        this.inventoryInStock = inventoryInStock;
    }

    //Add books to inventory
    public void addToInventory(int quantityToAdd) {
        if (quantityToAdd > 0) {
            inventoryInStock += quantityToAdd;
            System.out.println(quantityToAdd + " " + title + "(s) added to inventory.");
        } else {
            System.out.println("Invalid quantity. Please provide a positive quantity to add.");
        }
    }

    //Sell books
    public boolean sell(int quantityToSell) {
        if (quantityToSell > 0 && quantityToSell <= inventoryInStock) {
            inventoryInStock -= quantityToSell;
            System.out.println(quantityToSell + " " + title + "(s) sold.");
            return true; // Sale successful
        } else {
            System.out.println("Sale failed. Insufficient stock.");
            return false; // Sale failed
        }
    }

    //Getter methods
    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getIsbn() {
        return isbn;
    }

    public double getPrice() {
        return price;
    }

    public int getInventoryInStock() {
        return inventoryInStock;
    }

    //Setter methods
    public void setPrice(double price) {
        this.price = price;
    }

    public void setInventoryInStock(int InventoryInStock) {
        this.inventoryInStock = inventoryInStock;
    }
}
