public class DVD {
    private String title;
    private String director;
    private String genre;
    private double price;
    private int InventoryInStock;

    //Constructor
    public DVD(String title, String director, String genre, double price, int InventoryInStock) {
        this.title = title;
        this.director = director;
        this.genre = genre;
        this.price = price;
        this.InventoryInStock = InventoryInStock;
    }

    //Add DVDs to inventory
    public void addToInventory(int InventoryToAdd) {
        if (InventoryToAdd > 0) {
            InventoryInStock += InventoryToAdd;
            System.out.println(InventoryToAdd + " " + title + " DVDs added to inventory.");
        } else {
            System.out.println("Invalid quantity. Please provide a positive quantity to add.");
        }
    }

    //Sell DVDs
    public boolean sell(int InventoryToSell) {
        if (InventoryToSell > 0 && InventoryToSell <= InventoryInStock) {
            InventoryInStock -= InventoryToSell;
            System.out.println(InventoryToSell + " " + title + " DVDs sold.");
            return true; // Sale successful
        } else {
            System.out.println("Sale failed. Not enough in stock.");
            return false; // Sale failed
        }
    }

    //Getter methods
    public String getTitle() {
        return title;
    }

    public String getDirector() {
        return director;
    }

    public String getGenre() {
        return genre;
    }

    public double getPrice() {
        return price;
    }

    public int getInventoryInStock() {
        return InventoryInStock;
    }

    //Setter methods
    public void setPrice(double price) {
        this.price = price;
    }

    public void setInventoryInStock(int InventoryInStock) {
        this.InventoryInStock = InventoryInStock;
    }
}
