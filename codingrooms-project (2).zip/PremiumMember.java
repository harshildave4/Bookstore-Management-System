public class PremiumMember {
    private String name;
    private String email;
    private double totalSpending;
    private boolean monthlyFeesPaid;

    //Constructor
    public PremiumMember(String name, String email) {
        this.name = name;
        this.email = email;
        this.totalSpending = 0.0;
        this.monthlyFeesPaid = false;   
    }

    //Update premium member information
    public void updateMemberInfo(String newName, String newEmail) {
        name = newName;
        email = newEmail;
    }

    //Getter methods
    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public double getTotalSpending() {
        return totalSpending;
    }

    public boolean isFeesPaid() {
        return monthlyFeesPaid;
    }

    //Method to add to the total spending of the premium member after purchase
    public void addToTotalSpending(double amount) {
        if (amount > 0) {
            totalSpending += amount;
        } else {
            System.out.println("Invalid amount. Please provide a positive amount.");
        }
    }

    //Method used to pay membership fees
    public void payMembershipFee() {
        monthlyFeesPaid = true;
        System.out.println("Membership fee paid successfully.");
    }
}
