import java.util.ArrayList;

public class Bookstore {
    private ArrayList<Book> books;
    private ArrayList<CD> cds;
    private ArrayList<DVD> dvds;
    private ArrayList<Member> regularMembers;
    private ArrayList<PremiumMember> premiumMembers;

    public Bookstore() {
        books = new ArrayList<>();
        cds = new ArrayList<>();
        dvds = new ArrayList<>();
        regularMembers = new ArrayList<>();
        premiumMembers = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public void addCD(CD cd) {
        cds.add(cd);
    }

    public void addDVD(DVD dvd) {
        dvds.add(dvd);
    }

    public void addRegularMember(Member member) {
        regularMembers.add(member);
    }

    public void addPremiumMember(PremiumMember premiumMember) {
        premiumMembers.add(premiumMember);
    }

    public double purchaseRegularMember(Member member, ArrayList<Book> purchasedBooks, ArrayList<CD> purchasedCDs, ArrayList<DVD> purchasedDVDs) {
    double totalCost = 0.0;

    //Decrease inventory for purchased books
    for (Book book : purchasedBooks) {
        if (book.getInventoryInStock() > 0) {
            book.setInventoryInStock(book.getInventoryInStock() - 1);
            totalCost += book.getPrice();
        }
    }

    //Decrease inventory for purchased CDs
    for (CD cd : purchasedCDs) {
        if (cd.getInventoryInStock() > 0) {
            cd.setInventoryInStock(cd.getInventoryInStock() - 1);
            totalCost += cd.getPrice();
        }
    }

    //Decrease inventory for purchased DVDs
    for (DVD dvd : purchasedDVDs) {
        if (dvd.getInventoryInStock() > 0) {
            dvd.setInventoryInStock(dvd.getInventoryInStock() - 1);
            totalCost += dvd.getPrice();
        }
    }

    //Check if the member is not null before updating spending
    if (member != null) {
        member.addToTotalSpending(totalCost);
    }

    updateInventory(purchasedBooks, purchasedCDs, purchasedDVDs);
    return totalCost;
}

    public double purchasePremiumMember(PremiumMember member, ArrayList<Book> purchasedBooks, ArrayList<CD> purchasedCDs, ArrayList<DVD> purchasedDVDs) {
    double totalCost = 0.0;

    //Decrease inventory for purchased books
    for (Book book : purchasedBooks) {
        if (book.getInventoryInStock() > 0) {
            book.setInventoryInStock(book.getInventoryInStock() - 1);
            totalCost += book.getPrice();
        }
    }

    //Decrease inventory for purchased CDs
    for (CD cd : purchasedCDs) {
        if (cd.getInventoryInStock() > 0) {
            cd.setInventoryInStock(cd.getInventoryInStock() - 1);
            totalCost += cd.getPrice();
        }
    }

    //Decrease inventory for purchased DVDs
    for (DVD dvd : purchasedDVDs) {
        if (dvd.getInventoryInStock() > 0) {
            dvd.setInventoryInStock(dvd.getInventoryInStock() - 1);
            totalCost += dvd.getPrice();
        }
    }

    //Check if the premium member is not null before updating spending
    if (member != null) {
        member.addToTotalSpending(totalCost);
    }

    updateInventory(purchasedBooks, purchasedCDs, purchasedDVDs);
    return totalCost;
}

    public void displayInventory() {
        System.out.println("***** Inventory *****");
        System.out.println("Books:");
        for (Book book : books) {
            System.out.println(book.getTitle() + " - Price: $" + book.getPrice());
        }
        System.out.println("CDs:");
        for (CD cd : cds) {
            System.out.println(cd.getTitle() + " - Price: $" + cd.getPrice());
        }
        System.out.println("DVDs:");
        for (DVD dvd : dvds) {
            System.out.println(dvd.getTitle() + " - Price: $" + dvd.getPrice());
        }
    }

    public void displayMembers() {
        System.out.println("***** Members *****");
        System.out.println("Regular Members:");
        for (Member member : regularMembers) {
            System.out.println("Name: " + member.getName() + " - Email: " + member.getEmail() + " - Total Spending: $" + member.getTotalSpending());
        }
        System.out.println("Premium Members:");
        for (PremiumMember premiumMember : premiumMembers) {
            System.out.println("Name: " + premiumMember.getName() + " - Email: " + premiumMember.getEmail() + " - Total Spending: $" + premiumMember.getTotalSpending());
        }
    }

    public Book findBookByTitle(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    public CD findCDByTitle(String title) {
        for (CD cd : cds) {
            if (cd.getTitle().equalsIgnoreCase(title)) {
                return cd;
            }
        }
        return null;
    }

    public DVD findDVDByTitle(String title) {
        for (DVD dvd : dvds) {
            if (dvd.getTitle().equalsIgnoreCase(title)) {
                return dvd;
            }
        }
        return null;
    }

    //Find regular member by email 
    public Member findRegularMemberByEmail(String email) {
        for (Member member : regularMembers) {
            if (member.getEmail().equalsIgnoreCase(email)) {
                return member; //Found regular member with a matching email
        }
    }
    return null; //Regular member not found
}

//Find premium member by email 
    public PremiumMember findPremiumMemberByEmail(String email) {
        for (PremiumMember premiumMember : premiumMembers) {
            if (premiumMember.getEmail().equalsIgnoreCase(email)) {
                return premiumMember; //Found premium member with a matching email
        }
    }
    return null; //Premium member not found
}

    public void registerPremiumMember(String name, String email, String paymentMethod) {
        PremiumMember premiumMember = new PremiumMember(name, email);
        premiumMember.payMembershipFee();
        addPremiumMember(premiumMember);
    }

    public void updateInventory(ArrayList<Book> purchasedBooks, ArrayList<CD> purchasedCDs, ArrayList<DVD> purchasedDVDs) {
        for (Book book : purchasedBooks) {
            books.remove(book);
        }
        for (CD cd : purchasedCDs) {
            cds.remove(cd);
        }
        for (DVD dvd : purchasedDVDs) {
            dvds.remove(dvd);
        }
    }
}
