public class Member {
    private String name;
    private String email;
    private double totalSpending;

    //Constructor
    public Member(String name, String email) {
        this.name = name;
        this.email = email;
        this.totalSpending = 0.0;
    }

    //Update member information
    public void updateMemberInfo(String newName, String newEmail) {
        name = newName;
        email = newEmail;
    }

    //Getter methods
    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public double getTotalSpending() {
        return totalSpending;
    }

    //Method used to add to the total spending of the member after purchase
    public void addToTotalSpending(double amount) {
        if (amount > 0) {
            totalSpending += amount;
        } else {
            System.out.println("Please provide a positive number.");
        }
    }
}
